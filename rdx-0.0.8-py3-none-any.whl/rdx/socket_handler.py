import socketio
from socketio.exceptions import *
import datetime
import time
import copy


class SocketHandler:
    sio = socketio.Client()

    def __init__(self, service_id, parent_ids):
        """
        The constructor of socket handler for rdx application.
  
        Parameters:
            service_id (str): An id to be assigned to given usecase.
            parent_ids (list): The list of parent service ids.
        
        Returns:
            None
        """
        self.rooms = []
        self.service_id = service_id
        self.parent_ids = parent_ids
        self.params = {}

    def acknowledgement(self, id):
        self.sio.emit('acknowledgement', {"id": id})
        
    def run(self, ip="localhost", port=5000, *args, **kwargs):
        """
        The function to connect to the rdx server and run the socket handler.
  
        Parameters:
            ip (str): An ip of the device running rdx application.
            port (int): A port number of server running the rdx application.
          
        Returns:
            None
        """
        serverUrl = "http://{}:{}".format(ip, port)
        self.configurations(*args, **kwargs)
        
        while True:
            try:
                self.sio.connect(serverUrl)
                break
            except ConnectionError:
                print("Connection error. Retrying ...!")
                time.sleep(10)
            except ConnectionRefusedError:
                print("Connection refused error. Retrying ...!")
                time.sleep(10)

    def configurations(self, *args, **kwargs):
        @self.sio.event
        def connect():
            if not len(self.rooms):
                self.sio.emit(
                    'join', {
                        "room": self.service_id
                    }
                )
                self.sio.emit(
                    'rooms', {
                        "parent_ids": self.parent_ids, 
                        "usecase_id": self.service_id
                    }
                )
        
        @self.sio.on('stop')
        def disconnect_from_server(data):
            self.acknowledgement(data["id"])
            if data["data"] == self.service_id:
                for room in self.rooms:
                    self.sio.emit('leave', {"room": room})
                self.sio.emit('leave', {"room": self.service_id})   
                self.sio.disconnect()
            
    def on_disconnect(self, func):
        @self.sio.on('disconnect')
        def wrap(*args, **kwargs):
            return func(*args, **kwargs)
        return wrap

    def add_camera_handler(self, func):
        @self.sio.on('join_room')
        def wrap(data, *args, **kwargs):
            self.acknowledgement(data["id"])
            if data['room'] not in self.rooms:
                print("join room ", data['room'])
                self.sio.emit('join', {"room": data['room']})
                self.rooms.append(data['room'])
            else:
                return None
            dictionary = {
                "camera_id": data['camera_id'],
                "camera_name": data['camera_name'],
                "location": data['location']
            }
            return func(dictionary, *args, **kwargs)
        return wrap

    def remove_camera_handler(self, func):
        @self.sio.on('leave_room')
        def wrap(room, *args, **kwargs):
            print("leave room ", room['data'])
            self.acknowledgement(room["id"])
            if room['data'] in self.rooms:
                self.sio.emit('leave', {"room": room['data']})
                self.rooms.remove(room['data'])
            
            dictionary = {
                "camera_id": room['data'].split("_")[1]
            }
            return func(dictionary, *args, **kwargs)
        return wrap

    def usecase_params_handler(self, func):
        @self.sio.on('params')
        def wrap(data, *args, **kwargs):
            self.acknowledgement(data["id"])
            params = copy.deepcopy(data["data"])
            camera_id = params.pop('camera_id')
            del params['service_id']
            self.params[camera_id] = params
            return func(data["data"], *args, **kwargs)
        return wrap

    def metadata(self, func):
        @self.sio.on('message')
        def wrap(*args, **kwargs):
            return func(*args, **kwargs)
        return wrap

    def save_video(self, camera_id, parent_id, video_name):
        dictionary = {
            "camera_id": camera_id,
            "video_name": video_name,
            "room": parent_id
        }
        self.sio.emit('save_video', dictionary)
    
    def save_image(self, camera_id, parent_id, buffer_index, image_name=None, type="Alert", bbox=None):
        """
        The function to save an image for alert/report.
  
        Parameters:
            camera_id (str): 
                The camera id from which the event is generated.
            parent_id (str): 
                The parent id which detected the object for which event is generated.
            buffer_index (int): 
                The index of the frame from buffer cache which needs to be saved for given event.
            image_name (str): 
                The name of the image to be saved for given event. (default:None)
            type (str) [Alert/Report]: 
                The type of an event for which the image to be saved. (default:Alert)
            bbox (list): 
                The list of dictionaries of bounding box coordinates. (default:None)
          
        Returns:
            image_name: A name used to save the image for event.
        """
        if image_name is None:
            image_name = "img_{}_{}.jpg".format(
                self.service_id, 
                str(datetime.datetime.utcnow().timestamp()).replace(".", ""))

        dictionary = {
            "camera_id": camera_id,
            "image_name": image_name,
            "buffer_index": buffer_index,
            "bbox": bbox,
            "type": type,
            "room": parent_id            
        }
        self.sio.emit('save_image', dictionary)
        return image_name

    def delete_image(self, camera_id, parent_id, image_name, type="Alert"):
        """
        The function to delete an image for alert/report.
  
        Parameters:
            camera_id (str): 
                The camera id from which the event was generated.
            parent_id (str): 
                The parent id which detected the object for which event was generated.
            image_name (str): 
                The name of the image to be deleted.
            type (str) [Alert/Report]: 
                The type of an event for which the image was generated. (default:Alert)
          
        Returns:
            None.
        """
        dictionary = {
            "camera_id": camera_id,
            "image_name": image_name,
            "type": type,
            "room": parent_id
        }
        self.sio.emit('delete_image', dictionary)
    
    def save_alert(self, camera_id, parent_id, alert, buffer_index, bbox=None, 
                    image_required=True, prev_images=None, video_required=False):
        """
        The function to save an image for alert/report.
  
        Parameters:
            camera_id (str): 
                The camera id from which the alert is generated.
            parent_id (str): 
                The parent id which detected the object for which alert is generated.
            alert (str): 
                The name of an alert to be generated.
            buffer_index (int): 
                The index of the frame from buffer cache which needs to be saved for given alert.
            bbox (list): 
                The list of dictionaries of bounding box coordinates. (default:None)
            image_required (bool): 
                The flag for saving image for given alert. (default:True)
            prev_images (str): 
                The name of the image previously saved to be logged for given alert. (default:None)
            video_required (bool): 
                The flag for saving video for given alert. (default:False)
          
        Returns:
            dictionary (dict): 
                A dictionary of data sent to server to generate an alert.
        """
        dictionary = {
            "Camera_id": camera_id,
            "Service_id": self.service_id,
            "Alert": alert,
            "Timestamp": datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            "Image_path": None,
            "Video_path": None
        }

        if image_required:
            image_name = "img_{}_{}.jpg".format(
                self.service_id, 
                str(datetime.datetime.utcnow().timestamp()).replace(".", ""))
            dictionary["Image_path"] = [image_name]
            self.save_image(camera_id, parent_id, buffer_index, image_name=image_name, bbox=bbox)
        
        if video_required:
            video_name = "vid_{}_{}.mp4".format(
                self.service_id, 
                str(datetime.datetime.utcnow().timestamp()).replace(".", ""))
            dictionary["Video_path"] = [video_name]
            self.save_video(camera_id, parent_id, video_name)

        if prev_images is not None:
            dictionary["Image_path"] = prev_images.append(image_name)
        self.sio.emit("alert", dictionary)
        return dictionary

    def save_report(self, camera_id, service_id, parent_id=None, buffer_index=None, image_required=False, bbox=None, **kwargs):
        dictionary = {
            "camera_id": camera_id,
            "service_id": service_id
        }
        dictionary.update(kwargs)

        if image_required:
            image_name = "img_{}_{}.jpg".format(
                self.service_id, 
                str(datetime.datetime.utcnow().timestamp()).replace(".", ""))
            dictionary["Image_path"] = image_name
            self.save_image(camera_id, parent_id, image_name, buffer_index, bbox=bbox, type="Report")

        self.sio.emit("report", dictionary)
        return dictionary